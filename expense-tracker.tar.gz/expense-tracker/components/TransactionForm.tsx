"use client";
import { useState, useEffect } from "react";
import { Transaction } from "@/types";
import { useCreateTransaction, useUpdateTransaction, useCategories } from "@/lib/hooks";

interface Props {
  open: boolean;
  onClose: () => void;
  editing?: Transaction | null;
}

const today = () => new Date().toISOString().split("T")[0];

export default function TransactionForm({ open, onClose, editing }: Props) {
  const { data: categories = [] } = useCategories();
  const create = useCreateTransaction();
  const update = useUpdateTransaction();

  const [form, setForm] = useState({
    type: "expense" as "income" | "expense",
    amount: "",
    category: "",
    note: "",
    date: today(),
  });

  useEffect(() => {
    if (editing) {
      setForm({
        type: editing.type,
        amount: String(editing.amount),
        category: editing.category,
        note: editing.note,
        date: editing.date,
      });
    } else {
      setForm({ type: "expense", amount: "", category: "", note: "", date: today() });
    }
  }, [editing, open]);

  if (!open) return null;

  const isPending = create.isPending || update.isPending;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const amount = parseFloat(form.amount.replace(/,/g, ""));
    if (!amount || !form.category) return;

    const payload = { ...form, amount };

    if (editing) {
      await update.mutateAsync({ id: editing.id, data: payload });
    } else {
      await create.mutateAsync(payload);
    }
    onClose();
  }

  const filteredCategories = categories.filter((c: { type?: string }) =>
    !c.type || c.type === form.type
  );

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="w-full sm:max-w-md bg-white dark:bg-gray-900 rounded-t-2xl sm:rounded-2xl shadow-2xl p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            {editing ? "Chỉnh sửa giao dịch" : "Thêm giao dịch"}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
        </div>

        {/* Income / Expense toggle */}
        <div className="flex rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700">
          {(["expense", "income"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setForm((f) => ({ ...f, type: t, category: "" }))}
              className={`flex-1 py-2.5 text-sm font-medium transition-colors ${
                form.type === t
                  ? t === "expense"
                    ? "bg-red-500 text-white"
                    : "bg-emerald-500 text-white"
                  : "bg-white dark:bg-gray-800 text-gray-500"
              }`}
            >
              {t === "expense" ? "Chi tiêu" : "Thu nhập"}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Số tiền (VNĐ)
            </label>
            <input
              type="number"
              required
              min={1}
              placeholder="100,000"
              value={form.amount}
              onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))}
              className="w-full border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 text-lg font-mono bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Danh mục
            </label>
            <div className="grid grid-cols-4 gap-2">
              {filteredCategories.map((cat: { id: string; icon: string; name: string; color: string }) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, category: cat.name }))}
                  className={`flex flex-col items-center gap-1 p-2 rounded-xl border text-xs transition-all ${
                    form.category === cat.name
                      ? "border-violet-500 bg-violet-50 dark:bg-violet-950 text-violet-700 dark:text-violet-300"
                      : "border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400"
                  }`}
                >
                  <span className="text-xl">{cat.icon}</span>
                  <span className="leading-tight text-center">{cat.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Note */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Ghi chú
            </label>
            <input
              type="text"
              placeholder="Mô tả ngắn (tuỳ chọn)"
              value={form.note}
              onChange={(e) => setForm((f) => ({ ...f, note: e.target.value }))}
              className="w-full border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500"
            />
          </div>

          {/* Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Ngày
            </label>
            <input
              type="date"
              required
              value={form.date}
              onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
              className="w-full border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500"
            />
          </div>

          <button
            type="submit"
            disabled={isPending || !form.category || !form.amount}
            className="w-full py-3.5 rounded-xl font-semibold text-white transition-all disabled:opacity-50 bg-violet-600 hover:bg-violet-700 active:scale-95"
          >
            {isPending ? "Đang lưu..." : editing ? "Cập nhật" : "Thêm giao dịch"}
          </button>
        </form>
      </div>
    </div>
  );
}
